from PPlay.gameimage import GameImage

class Popup:

    def __init__(self, janela):
        self.janela = janela
        self.objeto = GameImage("images/popup_inventario.png")
        self.largura = self.objeto.width
        self.altura = self.objeto.height
        self.objeto.set_position(
            (self.janela.width/2 - self.largura/2),
            self.janela.height/2 - self.altura/2)

    def draw(self):
        self.objeto.draw()

class botao_repor:
    def __init__(self, popup, janela):
        self.janela = janela
        self.popup = popup

        self.objeto = GameImage("images/botao_repor_inventario.png")
        self.largura = self.objeto.width
        self.altura = self.objeto.height
        self.objeto.set_position((self.janela.width/2 - popup.largura / 2) + 10, self.janela.height/2 - popup.altura/2 + 2*self.altura)

    def draw(self):
        self.objeto.draw()

    def clicked(self):
        return 1

class botao_comer:
    def __init__(self, popup, janela):
        self.janela = janela
        self.popup = popup

        self.objeto = GameImage("images/botao_comer.png")
        self.largura = self.objeto.width
        self.altura = self.objeto.height
        self.objeto.set_position((self.janela.width/2 - popup.largura / 2) + 10,
                                 self.janela.height / 2 - popup.altura / 2 + 4* self.altura + 2)

    def draw(self):
        self.objeto.draw()

    def clicked(self):
        return 2

class botao_dormir:
    def __init__(self, popup, janela):
        self.janela = janela
        self.popup = popup

        self.objeto = GameImage("images/botao_dormir.png")
        self.largura = self.objeto.width
        self.altura = self.objeto.height
        self.objeto.set_position((self.janela.width/2 - popup.largura / 2) + 10,
                                 self.janela.height / 2 - popup.altura / 2 + 3*self.altura + 1)

    def draw(self):
        self.objeto.draw()

    def clicked(self):
        return 3